# EUI grid research delivery — 2026-10-14

Start with REPORT.md (theory, assumptions, actual results, unresolved issues), then NEXT_CODEX_TASK_PROMPT.md (bounded independent next tasks).

The full repository-shaped payload is research/grid_discovery_20261014_r1/. It contains code, raw results, two real clean reruns, tests, ledgers, primary-source access notes, and GitHub delivery status. The byte-identical original input ZIP is frozen_input/EUI_Pro_Grid_Theory_20261014.zip.

No remote commit was made. grid_discovery_20261014_r1.patch only adds the new research directory. Its intended baseline is 62fa763aff42e4bedf82b5de19bc9f05c5ed83b2 on codex/eui-grid-pro-20261014; existing draft PR2 was untouched. Actual local patch checks and the frozen remote/local Git-tree match are in DELIVERY_VALIDATION.json. Codex, not the user, is assigned application/commit/push and remote reread.

Run `python verify_delivery.py` in this extracted directory to check the full manifest. This does not run the scientific scripts or contact a network. See research/grid_discovery_20261014_r1/REPRODUCE.md for bounded fresh-output science reproduction.

The manifest excludes itself, explicitly. The SHA-256 of the entire ZIP is in the separately provided .sha256 file. No font files, credentials, private meeting recordings or binaries are included.
