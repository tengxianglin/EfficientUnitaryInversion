#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'DELIVERY_MANIFEST.json').read_text())
expected=set()
for item in m['files']:
    rel=PurePosixPath(item['path'])
    if rel.is_absolute() or '..' in rel.parts or str(rel) in expected:
        raise SystemExit('Unsafe or duplicate path')
    expected.add(str(rel));p=root/str(rel)
    if p.is_symlink() or not p.is_file():raise SystemExit('Missing/unsafe: '+str(rel))
    if p.stat().st_size!=item['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
        raise SystemExit('Hash/size mismatch: '+str(rel))
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
if actual != expected|{'DELIVERY_MANIFEST.json'}:raise SystemExit('Unlisted or absent files')
print('PASS: '+str(len(expected))+' payload files, paths, sizes and SHA-256; manifest excluded from self-hash')
